from pip import main
from json import load
from time import sleep

def import_or_install(package):
    try:
        __import__(package)
    except ImportError:
        main(['install', package])
import_or_install("pywin32")
import win32gui
import win32con

def ScreenOFF():
    """
    Function to turn off the screen.
    """
    return win32gui.SendMessage(win32con.HWND_BROADCAST,
                            win32con.WM_SYSCOMMAND, win32con.SC_MONITORPOWER, 2)

def ScreenON():
    """
    Function to turn on the screen.
    """
    return win32gui.SendMessage(win32con.HWND_BROADCAST,
                            win32con.WM_SYSCOMMAND, win32con.SC_MONITORPOWER, -1)

data = {}
with open('./conf.json', 'r') as file:
    data = load(file)
waiting_time = data["delay"]

running = True if data["running"] else False
while running:

    ScreenOFF()
    sleep(waiting_time)

    with open('./conf.json', 'r') as file:
        data = load(file)
        running = True if data["running"] is True else False
        waiting_time = data["delay"]
