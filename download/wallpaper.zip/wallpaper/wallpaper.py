import pathlib
import random
import ctypes

from os import listdir
from os.path import isfile, join

folder = f"{pathlib.Path().resolve()}\\image\\"
images = [f for f in listdir(folder) if isfile(join(folder, f))]
image = random.choice(images)
path = f"{folder}{image}"

# 0: Center, 1: Stretch, 2: Tile, 6: Fit
wallpaper_style = 0

# Load the image
SPI_SETDESKWALLPAPER = 20
wallpaper = ctypes.c_wchar_p(path)

try:
    ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, wallpaper, wallpaper_style)
    print(f"Wallpeper set to: {image}")
except Exception as e:
    print(e)