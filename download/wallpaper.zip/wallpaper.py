import pathlib
import random
import ctypes
import json

from os import listdir
from os.path import isfile, join
from time import sleep

folder = f"{pathlib.Path().resolve()}\\image\\"
images = [f for f in listdir(folder) if isfile(join(folder, f))]
image = random.choice(images)
path = f"{folder}{image}"

# 0: Center, 1: Stretch, 2: Tile, 6: Fit
wallpaper_style = 0

# Load the image
SPI_SETDESKWALLPAPER = 20
wallpaper = ctypes.c_wchar_p(path)

try:
    data = {}
    with open('./conf.json', 'r') as file:
        data = json.load(file)
    waiting_time = data["delay"]

    running = True if data["running"] else False
    while running:

        with open('./conf.json', 'r') as file:
            data = json.load(file)
        running = True if data["running"] is True else False
        waiting_time = data["delay"]
        
        ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, wallpaper, wallpaper_style)
        print(f"Wallpeper set to: {image}")
        sleep(waiting_time)

except Exception as e:
    print(e)