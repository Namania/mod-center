from socket import gethostname
from time import sleep
from connection import import_or_install, db
cursor = db.cursor()

import_or_install("FindMyIP")
from FindMyIP import internal, internet

while True:
    if (internet()):

        hostname = gethostname()
        ipv4 = internal()
        already_exist = False

        cursor.execute("SELECT hostname, ip FROM `user` WHERE hostname=%s AND ip=%s", (hostname, ipv4))
        for user in cursor:
            already_exist = True
            print(f"{hostname} already in db..")

        if not already_exist:
            cursor.execute("INSERT INTO `user` (hostname, ip) VALUES (%s, %s)", (hostname, ipv4))
            print(f"{hostname}: {ipv4} added !")

        db.commit()

    sleep(30)
