import json
from pip import main

def import_or_install(package):
    try:
        __import__(package)
    except ImportError:
        main(['install', package])

import_or_install("mysql-connector-python")
import mysql.connector

try:
    with open(f"./config.json") as json_file:
        config = json.load(json_file)
    db = mysql.connector.connect(
        user=config["username"],
        password=config["password"],
        host=config["host"],
        port=config["port"],
        database=config["db_name"]
    )
except Exception:
    raise Exception("Error connecting database !")