from pip import main
from time import sleep
from json import load

def import_or_install(package):
    try:
        __import__(package)
    except ImportError:
        main(['install', package])
import_or_install("ctypes")
import_or_install("comtypes")
import_or_install("pycaw")
import_or_install("playsound3")

from playsound3 import playsound
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
 
devices = AudioUtilities.GetSpeakers()
interface = devices.Activate(
   IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume = cast(interface, POINTER(IAudioEndpointVolume))

playsound('./son.mp3', True)

data = {}
with open('./conf.json', 'r') as file:
    data = load(file)
waiting_time = data["delay"]

running = True if data["running"] else False
while True:
    
    volume.SetMasterVolumeLevel(-0.0, None)
    volume.SetMute(0, None)
    sleep(waiting_time)

    with open('./conf.json', 'r') as file:
        data = load(file)
    running = True if data["running"] is True else False
    waiting_time = data["delay"]