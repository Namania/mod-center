import os
import time
import json

data = {}
with open('./conf.json', 'r') as file:
    data = json.load(file)
waiting_time = data["delay"]

running = True if data["running"] else False
while running:

    with open('./conf.json', 'r') as file:
        data = json.load(file)
    running = True if data["running"] is True else False
    waiting_time = data["delay"]

    os.system("start https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    time.sleep(waiting_time)